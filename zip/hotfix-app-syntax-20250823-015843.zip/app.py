from __future__ import annotations
import os
from pathlib import Path
from flask import Flask, render_template, request, jsonify, redirect, url_for, render_template_string
import pandas as pd

from excel_dal import (
    EXCEL_PATH, ensure_workbook,
    read_goals, read_challenges, read_capabilities, read_resources,
    read_areas, read_subareas,
    read_goal_challenge, read_capability_challenge, read_capability_resource,
    update_goal, update_challenge, update_capability, update_resource,
    update_area, update_subarea,
    add_area, add_subarea, add_goal, add_challenge, add_capability, add_resource,
    toggle_link_goal_challenge, toggle_link_capability_challenge, toggle_link_capability_resource,
    delete_challenge,
    WriteLockedError
)

from changelog_dal import read_changelog

app = Flask(__name__)


@app.get('/__routes')
def __routes():
    return '<pre>' + '\n'.join(sorted(str(r) for r in app.url_map.iter_rules())) + '</pre>'


@app.before_request
def _ensure_xlsx():
    ensure_workbook()

def _fmt_date_only(x):
    if x in (None, '', pd.NaT):
        return ''
    try:
        d = pd.to_datetime(x, errors='coerce')
        if pd.isna(d): return ''
        return d.date().isoformat()
    except Exception:
        return ''

@app.context_processor
def inject_excel_path():
    return dict(excel_path=str(Path(EXCEL_PATH).resolve()))


@app.get('/')
def home():
    # If you’re using changelog_dal.py, prefer: from changelog_dal import read_changelog
    # and call that instead of reading directly.
    csv_path = Path(os.environ.get("KOKO_ROADMAP_CHANGELOG", "changelog.csv"))
    if not csv_path.exists():
        rows = []
    else:
        df = pd.read_csv(csv_path)
        # normalise column names
        cols = {c.lower(): c for c in df.columns}
        # pick a sortable date col
        if 'timestamp' in cols:
            sortcol = cols['timestamp']
        elif 'date' in cols:
            sortcol = cols['date']
        else:
            sortcol = None
        if sortcol:
            df['_sort'] = pd.to_datetime(df[sortcol], errors='coerce')
            df = df.sort_values('_sort', ascending=False).drop(columns=['_sort'])
        rows = df.to_dict(orient='records')

    return render_template('index.html', changelog=rows)



@app.get('/goals')
def goals():
    gs = read_goals().copy()
    ch = read_challenges()
    gc = read_goal_challenge()
    titles_by_id = ch.set_index('id')['title'].to_dict() if not ch.empty else {}
    challenge_titles = {gid: [titles_by_id.get(cid,'') for cid in gc[gc['goal_id']==gid]['challenge_id'].tolist()] for gid in gs['id'].tolist()} if not gs.empty else {}
    rows = []
    for _, r in gs.iterrows():
        rows.append(dict(
            id=int(r['id']),
            name=r.get('name',''),
            year=int(r.get('year')) if pd.notna(r.get('year')) else '',
            due_date=r.get('due_date',''),
            due_date_disp=_fmt_date_only(r.get('due_date','')),
            description='' if (pd.isna(r.get('description')) or str(r.get('description')).lower()=='nan') else r.get('description',''),
            challenge_titles=sorted([t for t in challenge_titles.get(int(r['id']),[]) if t])
        ))
    return render_template('goals.html', goals=rows)

@app.get('/challenges')
def challenges():
    ch = read_challenges().copy()
    gs = read_goals()
    gc = read_goal_challenge()
    cc = read_capability_challenge()
    caps = read_capabilities()

    goal_due = {}
    if not gs.empty and not gc.empty:
        g_due = gs.set_index('id')['due_date'].to_dict()
        for cid in ch['id'].tolist():
            g_ids = gc[gc['challenge_id']==cid]['goal_id'].tolist()
            ds = pd.to_datetime([g_due.get(g) for g in g_ids], errors='coerce')
            goal_due[cid] = ds.min() if len(ds)>0 and not pd.isna(ds).all() else None

    cap_titles = caps.set_index('id')['title'].to_dict() if not caps.empty else {}
    cc_map = {cid: [cap_titles.get(k,'') for k in cc[cc['challenge_id']==cid]['capability_id'].tolist()] for cid in ch['id'].tolist()} if not ch.empty else {}

    rows = []
    for _, r in ch.iterrows():
        rows.append(dict(
            id=int(r['id']), title=r.get('title',''),
            due_date=r.get('due_date',''), due_date_disp=_fmt_date_only(r.get('due_date','')),
            earliest_goal_due_disp=_fmt_date_only(goal_due.get(int(r['id']))),
            description='' if (pd.isna(r.get('description')) or str(r.get('description')).lower()=='nan') else r.get('description',''),
            goal_titles=sorted([t for t in gc[gc['challenge_id']==int(r['id'])]['goal_id'].map(gs.set_index('id')['name']).fillna('').tolist() if t!='']),
            cap_titles=sorted([t for t in cc_map.get(int(r['id']),[]) if t!=''])
        ))
    return render_template('challenges.html', challenges=rows)

@app.get('/capabilities')
def capabilities():
    caps = read_capabilities().copy()
    cr = read_capability_resource()
    res = read_resources()
    cc = read_capability_challenge()
    ch = read_challenges()
    areas = read_areas()
    subs = read_subareas()

    caps = caps.merge(subs[['subarea_id','subarea_name','area_id']], how='left', on='subarea_id')
    caps = caps.merge(areas[['area_id','area_name','rank']].rename(columns={'rank':'area_rank'}), how='left', on='area_id')
    caps = caps.merge(subs[['subarea_id','rank']].rename(columns={'rank':'sub_rank'}), how='left', on='subarea_id')

    # compute earliest due date of linked challenges
    earliest_due = {}
    ch_due = ch.set_index('id')['due_date'].to_dict() if not ch.empty else {}
    for cap_id in caps['id'].tolist():
        cids = cc[cc['capability_id']==cap_id]['challenge_id'].tolist()
        ds = pd.to_datetime([ch_due.get(k) for k in cids], errors='coerce')
        earliest_due[cap_id] = ds.min() if len(ds) > 0 and not pd.isna(ds).all() else None

    res_titles = res.set_index('id')['title'].to_dict() if not res.empty else {}
    res_map = {cap_id: [res_titles.get(rid,'') for rid in cr[cr['capability_id']==cap_id]['resource_id'].tolist()] for cap_id in caps['id'].tolist()} if not caps.empty else {}

    rows = []
    for _, r in caps.iterrows():
        due_val = earliest_due.get(int(r['id']))
        due_iso = _fmt_date_only(due_val)  # ISO yyyy-mm-dd for both display and modal
        rows.append(dict(
            id=int(r['id']), title=r.get('title',''),
            subarea_id=int(r['subarea_id']) if pd.notna(r.get('subarea_id')) else None,
            area_id=int(r.get('area_id')) if pd.notna(r.get('area_id')) else None,
            area_name=r.get('area_name',''), subarea_name=r.get('subarea_name',''),
            description='' if (pd.isna(r.get('description')) or str(r.get('description')).lower()=='nan') else r.get('description',''),
            resource_titles=sorted([t for t in res_map.get(int(r['id']),[]) if t!='']),
            earliest_due_disp=due_iso,      # table column
            earliest_due_iso=due_iso        # modal input
        ))
    return render_template('capabilities.html',
                           capabilities=rows,
                           areas=read_areas().to_dict(orient='records'),
                           subareas=read_subareas().to_dict(orient='records'))

@app.get('/resources')
def resources():
    res = read_resources().copy()
    caps = read_capabilities()
    subs = read_subareas()
    areas = read_areas()
    cr = read_capability_resource()

    res = res.merge(subs[['subarea_id','subarea_name','area_id']], how='left', on='subarea_id')
    res = res.merge(areas[['area_id','area_name']], how='left', on='area_id')

    cap_titles = caps.set_index('id')['title'].to_dict() if not caps.empty else {}
    cap_map = {rid: [cap_titles.get(k,'') for k in cr[cr['resource_id']==rid]['capability_id'].tolist()] for rid in res['id'].tolist()} if not res.empty else {}

    rows = []
    for _, r in res.iterrows():
        rows.append(dict(
            id=int(r['id']), title=r.get('title',''),
            subarea_id=int(r['subarea_id']) if pd.notna(r.get('subarea_id')) else None,
            area_id=int(r.get('area_id')) if pd.notna(r.get('area_id')) else None,
            area_name=r.get('area_name',''), subarea_name=r.get('subarea_name',''),
            description='' if (pd.isna(r.get('description')) or str(r.get('description')).lower()=='nan') else r.get('description',''),
            cap_titles=sorted([t for t in cap_map.get(int(r['id']),[]) if t!=''])
        ))
    return render_template('resources.html', resources=rows, areas=read_areas().to_dict(orient='records'), subareas=read_subareas().to_dict(orient='records'))

@app.get('/areas')
def areas():
    ar = read_areas()
    sb = read_subareas()
    ar_sorted = ar.sort_values(['rank','area_name'], na_position='last', kind='stable')
    subs_by = {}
    for _, r in ar_sorted.iterrows():
        subs = sb[sb['area_id']==r['area_id']].sort_values(['rank','subarea_name'], na_position='last', kind='stable')
        subs_by[int(r['area_id'])] = [dict(subarea_id=int(x['subarea_id']), subarea_name=x.get('subarea_name',''), rank=(None if pd.isna(x.get('rank')) else int(x['rank']))) for _, x in subs.iterrows()]
    areas_rows = [dict(area_id=int(r['area_id']), area_name=r.get('area_name',''), rank=(None if pd.isna(r.get('rank')) else int(r['rank']))) for _, r in ar_sorted.iterrows()]
    return render_template('areas.html', areas=areas_rows, subareas_by_area=subs_by)

@app.get('/sankey')
def sankey():
    ch = read_challenges()
    cc = read_capability_challenge()
    caps = read_capabilities()
    cr = read_capability_resource()
    res = read_resources()
    subs = read_subareas()
    areas = read_areas()

    if not ch.empty:
        ch['_due'] = pd.to_datetime(ch['due_date'], errors='coerce')
        ch = ch.sort_values(['_due','title'], na_position='last', kind='stable')
    subs_rank = subs[['subarea_id','area_id','rank']].rename(columns={'rank':'sub_rank'})
    areas_rank = areas[['area_id','rank']].rename(columns={'rank':'area_rank'})
    caps2 = caps.merge(subs_rank, how='left', on='subarea_id').merge(areas_rank, how='left', on='area_id')
    if not caps2.empty:
        caps2 = caps2.sort_values(['area_rank','sub_rank','title'], na_position='last', kind='stable')
    res2 = res.merge(subs_rank, how='left', on='subarea_id').merge(areas_rank, how='left', on='area_id')
    if not res2.empty:
        res2 = res2.sort_values(['area_rank','sub_rank','title'], na_position='last', kind='stable')

    labels = []
    idx_ch = {}; idx_cap = {}; idx_res = {}

    for _, r in ch.iterrows():
        idx_ch[int(r['id'])] = len(labels)
        labels.append(f"⚑ {r.get('title','')}")

    for _, r in caps2.iterrows():
        idx_cap[int(r['id'])] = len(labels)
        labels.append(f"◆ {r.get('title','')}")

    for _, r in res2.iterrows():
        idx_res[int(r['id'])] = len(labels)
        labels.append(f"● {r.get('title','')}")

    sources, targets, values = [], [], []
    if not cc.empty:
        for _, r in cc.iterrows():
            c = int(r['challenge_id']); p = int(r['capability_id'])
            if c in idx_ch and p in idx_cap:
                sources.append(idx_ch[c]); targets.append(idx_cap[p]); values.append(1)
    if not cr.empty:
        for _, r in cr.iterrows():
            p = int(r['capability_id']); rs = int(r['resource_id'])
            if p in idx_cap and rs in idx_res:
                sources.append(idx_cap[p]); targets.append(idx_res[rs]); values.append(1)

    height = int(request.args.get('h', '900'))
    return render_template('sankey.html', sankey=dict(labels=labels, sources=sources, targets=targets, values=values), height=height)

# ----- Linking UIs -----
@app.get('/links/goal/<int:goal_id>')
def links_goal(goal_id: int):
    gs = read_goals(); ch = read_challenges(); gc = read_goal_challenge()
    g = gs[gs['id']==goal_id]
    if g.empty: return redirect(url_for('goals'))
    linked = set(gc[gc['goal_id']==goal_id]['challenge_id'].tolist())
    rows = ch.sort_values(['title']).to_dict(orient='records')
    return render_template_string("""
    {% extends 'base.html' %}{% block content %}
    <h2>Link Goal to Challenges: {{ g.name }}</h2>
    <form method="post">
      {% for r in rows %}
        <div><label><input type="checkbox" name="cid" value="{{ r.id }}" {% if r.id in linked %}checked{% endif %}> {{ r.title }}</label></div>
      {% endfor %}
      <div class="actions" style="margin-top:.75rem"><button class="btn primary">Save</button></div>
    </form>
    {% endblock %}
    """, g=dict(id=int(g.iloc[0]['id']), name=g.iloc[0]['name']), rows=rows, linked=linked)

@app.post('/links/goal/<int:goal_id>')
def links_goal_post(goal_id: int):
    ch = read_challenges()
    submitted = set([int(x) for x in request.form.getlist('cid')])
    all_ids = set(ch['id'].tolist()) if not ch.empty else set()
    for cid in all_ids:
        toggle_link_goal_challenge(goal_id, cid, cid in submitted)
    return redirect(url_for('goals'))


@app.get('/links/challenge/<int:cid>/capabilities')
def links_chal_caps(cid: int):
    caps = read_capabilities(); cc = read_capability_challenge()
    ch = read_challenges()
    c = ch[ch['id']==cid]
    if c.empty: return redirect(url_for('challenges'))
    linked = set(cc[cc['challenge_id']==cid]['capability_id'].tolist())
    rows = caps.sort_values(['title']).to_dict(orient='records')
    if request.args.get('embed') == '1':
        return render_template_string("""        <h3>Link Capabilities to Challenge: {{ c.title }}</h3>
        <form id="chal-caps-form" method="post" action="{{ url_for('links_chal_caps_post', cid=c.id) }}">
          {% for r in rows %}
            <div><label><input type="checkbox" name="pid" value="{{ r.id }}" {% if r.id in linked %}checked{% endif %}> {{ r.title }}</label></div>
          {% endfor %}
          <div class="actions" style="margin-top:.75rem">
            <button type="button" class="btn" id="cc_cancel">Cancel</button>
            <button class="btn primary">Save</button>
          </div>
        </form>
        """, c=dict(id=int(c.iloc[0]['id']), title=c.iloc[0]['title']), rows=rows, linked=linked)
    return render_template_string("""    {% extends 'base.html' %}{% block content %}
    <h2>Link Capabilities to Challenge: {{ c.title }}</h2>
    <form method="post">
      {% for r in rows %}
        <div><label><input type="checkbox" name="pid" value="{{ r.id }}" {% if r.id in linked %}checked{% endif %}> {{ r.title }}</label></div>
      {% endfor %}
      <div class="actions" style="margin-top:.75rem"><button class="btn primary">Save</button></div>
    </form>
    {% endblock %}
    """, c=dict(id=int(c.iloc[0]['id']), title=c.iloc[0]['title']), rows=rows, linked=linked)

@app.post('/links/challenge/<int:cid>/capabilities')
def links_chal_caps_post(cid: int):
    caps = read_capabilities()
    submitted = set([int(x) for x in request.form.getlist('pid')])
    all_ids = set(caps['id'].tolist()) if not caps.empty else set()
    for pid in all_ids:
        toggle_link_capability_challenge(pid, cid, pid in submitted)
    return redirect(url_for('challenges'))


@app.get('/links/challenge/<int:cid>/goals')
def links_chal_goals(cid: int):
    gs = read_goals(); gc = read_goal_challenge(); ch = read_challenges()
    c = ch[ch['id']==cid]
    if c.empty: return redirect(url_for('challenges'))
    linked = set(gc[gc['challenge_id']==cid]['goal_id'].tolist())
    rows = gs.sort_values(['name']).to_dict(orient='records')
    if request.args.get('embed') == '1':
        return render_template_string("""        <h3>Link Goals to Challenge: {{ c.title }}</h3>
        <form id="chal-goals-form" method="post" action="{{ url_for('links_chal_goals_post', cid=c.id) }}">
          {% for r in rows %}
            <div><label><input type="checkbox" name="gid" value="{{ r.id }}" {% if r.id in linked %}checked{% endif %}> {{ r.name }}</label></div>
          {% endfor %}
          <div class="actions" style="margin-top:.75rem">
            <button type="button" class="btn" id="cg_cancel">Cancel</button>
            <button class="btn primary">Save</button>
          </div>
        </form>
        """, c=dict(id=int(c.iloc[0]['id']), title=c.iloc[0]['title']), rows=rows, linked=linked)
    return render_template_string("""    {% extends 'base.html' %}{% block content %}
    <h2>Link Goals to Challenge: {{ c.title }}</h2>
    <form method="post">
      {% for r in rows %}
        <div><label><input type="checkbox" name="gid" value="{{ r.id }}" {% if r.id in linked %}checked{% endif %}> {{ r.name }}</label></div>
      {% endfor %}
      <div class="actions" style="margin-top:.75rem"><button class="btn primary">Save</button></div>
    </form>
    {% endblock %}
    """, c=dict(id=int(c.iloc[0]['id']), title=c.iloc[0]['title']), rows=rows, linked=linked)

@app.post('/links/challenge/<int:cid>/goals')
def links_chal_goals_post(cid: int):
    gs = read_goals()
    submitted = set(int(x) for x in request.form.getlist('gid'))
    all_ids = set(gs['id'].tolist()) if not gs.empty else set()
    for gid in all_ids:
        toggle_link_goal_challenge(gid, cid, gid in submitted)
    return redirect(url_for('challenges'))


@app.get('/links/capability/<int:pid>/resources')
def links_cap_res(pid: int):
    res = read_resources(); cr = read_capability_resource()
    caps = read_capabilities()
    p = caps[caps['id']==pid]
    if p.empty: return redirect(url_for('capabilities'))
    linked = set(cr[cr['capability_id']==pid]['resource_id'].tolist())
    rows = res.sort_values(['title']).to_dict(orient='records')
    return render_template_string("""
    {% extends 'base.html' %}{% block content %}
    <h2>Link Resources to Capability: {{ p.title }}</h2>
    <form method="post">
      {% for r in rows %}
        <div><label><input type="checkbox" name="rid" value="{{ r.id }}" {% if r.id in linked %}checked{% endif %}> {{ r.title }}</label></div>
      {% endfor %}
      <div class="actions" style="margin-top:.75rem"><button class="btn primary">Save</button></div>
    </form>
    {% endblock %}
    """, p=dict(id=int(p.iloc[0]['id']), title=p.iloc[0]['title']), rows=rows, linked=linked)

@app.post('/links/capability/<int:pid>/resources')
def links_cap_res_post(pid: int):
    res = read_resources()
    submitted = set([int(x) for x in request.form.getlist('rid')])
    all_ids = set(res['id'].tolist()) if not res.empty else set()
    for rid in all_ids:
        toggle_link_capability_resource(pid, rid, rid in submitted)
    return redirect(url_for('capabilities'))

# ----- Inline EDIT endpoints -----
def _get(field: str, default: str = '') -> str:
    if request.is_json:
        data = request.get_json(silent=True) or {}
        return (data.get(field, default) or '').strip()
    return (request.form.get(field, default) or '').strip()

@app.route('/goals/<int:goal_id>/edit-inline', methods=['POST'])
def goals_edit_inline(goal_id: int):
    name = _get('name'); year = _get('year'); due = _get('due_date'); desc = _get('description')
    if not name: return jsonify(ok=False, error='Name is required.'), 400
    if not year.isdigit(): return jsonify(ok=False, error='Year must be a number.'), 400
    try:
        update_goal(goal_id, name, int(year), due, desc)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True), 200

@app.route('/challenges/<int:challenge_id>/edit-inline', methods=['POST'])
def challenges_edit_inline(challenge_id: int):
    title = _get('title'); due = _get('due_date'); desc = _get('description')
    if not title: return jsonify(ok=False, error='Title is required.'), 400
    try:
        update_challenge(challenge_id, title, due, desc)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True), 200



@app.post('/challenges/<int:challenge_id>/delete-inline')
def challenges_delete_inline(challenge_id: int):
    # Cannot delete if linked to any goals or capabilities
    gc = read_goal_challenge()
    cc = read_capability_challenge()
    if (not gc.empty and (gc['challenge_id'] == int(challenge_id)).any()) or (not cc.empty and (cc['challenge_id'] == int(challenge_id)).any()):
        return jsonify(ok=False, error='Cannot delete: challenge is linked to goals or capabilities.'), 400
    try:
        delete_challenge(challenge_id)
    except WriteLockedError as e:
        return jsonify(ok=False, error=str(e)), 423
    except Exception as e:
        return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True), 200
@app.route('/capabilities/<int:capability_id>/edit-inline', methods=['POST'])
def capabilities_edit_inline(capability_id: int):
    title = _get('title'); subarea_id = _get('subarea_id'); desc = _get('description')
    if not title: return jsonify(ok=False, error='Title is required.'), 400
    if not subarea_id.isdigit(): return jsonify(ok=False, error='Sub-area is required.'), 400
    try:
        update_capability(capability_id, title, int(subarea_id), desc)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True), 200

@app.route('/resources/<int:resource_id>/edit-inline', methods=['POST'])
def resources_edit_inline(resource_id: int):
    title = _get('title'); subarea_id = _get('subarea_id'); desc = _get('description')
    if not title: return jsonify(ok=False, error='Title is required.'), 400
    try:
        sub_id = int(subarea_id) if subarea_id.isdigit() else None
        update_resource(resource_id, sub_id, title, desc)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True), 200

@app.route('/areas/<int:area_id>/edit-inline', methods=['POST'])
def areas_edit_inline(area_id: int):
    name = _get('area_name'); rank_raw = _get('rank')
    rank = int(rank_raw) if rank_raw and rank_raw.lstrip('-').isdigit() else None
    if not name: return jsonify(ok=False, error='Area name is required.'), 400
    try:
        update_area(area_id, name, rank)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True), 200

@app.route('/areas/sub/<int:subarea_id>/edit-inline', methods=['POST'])
def subareas_edit_inline(subarea_id: int):
    name = _get('subarea_name'); area_id_raw = _get('area_id'); rank_raw = _get('rank')
    if not name: return jsonify(ok=False, error='Sub-area name is required.'), 400
    if not area_id_raw.isdigit(): return jsonify(ok=False, error='Area is required.'), 400
    rank = int(rank_raw) if rank_raw and rank_raw.lstrip('-').isdigit() else None
    try:
        update_subarea(subarea_id, int(area_id_raw), name, rank)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True), 200

# ----- Inline ADD endpoints -----
@app.post('/goals/add-inline')
def goals_add_inline():
    name = _get('name'); year = _get('year'); due = _get('due_date'); desc = _get('description')
    if not name: return jsonify(ok=False, error='Name is required.'), 400
    if not year.isdigit(): return jsonify(ok=False, error='Year must be a number.'), 400
    try:
        new_id = add_goal(name, int(year), due, desc)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True, id=new_id), 200

@app.post('/challenges/add-inline')
def challenges_add_inline():
    title = _get('title'); due = _get('due_date'); desc = _get('description')
    if not title: return jsonify(ok=False, error='Title is required.'), 400
    try:
        new_id = add_challenge(title, due, desc)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True, id=new_id), 200

@app.post('/capabilities/add-inline')
def capabilities_add_inline():
    title = _get('title'); subarea_id = _get('subarea_id'); desc = _get('description')
    if not title: return jsonify(ok=False, error='Title is required.'), 400
    if not subarea_id.isdigit(): return jsonify(ok=False, error='Sub-area is required.'), 400
    try:
        new_id = add_capability(title, int(subarea_id), desc)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True, id=new_id), 200

@app.post('/resources/add-inline')
def resources_add_inline():
    title = _get('title'); subarea_id = _get('subarea_id'); desc = _get('description')
    if not title: return jsonify(ok=False, error='Title is required.'), 400
    if not subarea_id.isdigit(): return jsonify(ok=False, error='Sub-area is required.'), 400
    try:
        new_id = add_resource(title, int(subarea_id), desc)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True, id=new_id), 200

@app.post('/areas/add-inline')
def areas_add_inline():
    name = _get('area_name'); rank_raw = _get('rank')
    if not name: return jsonify(ok=False, error='Area name is required.'), 400
    rank = int(rank_raw) if rank_raw and rank_raw.lstrip('-').isdigit() else None
    try:
        new_id = add_area(name, rank)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True, id=new_id), 200

# NEW: add missing sub-area CREATE endpoint to match the UI
@app.post('/areas/sub/add-inline')
def subareas_add_inline():
    name = _get('subarea_name'); area_id_raw = _get('area_id'); rank_raw = _get('rank')
    if not name: return jsonify(ok=False, error='Sub-area name is required.'), 400
    if not area_id_raw.isdigit(): return jsonify(ok=False, error='Area is required.'), 400
    rank = int(rank_raw) if rank_raw and rank_raw.lstrip('-').isdigit() else None
    try:
        new_id = add_subarea(int(area_id_raw), name, rank)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True, id=new_id), 200

if __name__ == '__main__':
    app.run(debug=True)
