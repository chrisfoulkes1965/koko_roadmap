from __future__ import annotations
import os
from pathlib import Path
import pandas as pd

EXCEL_PATH = os.environ.get('KOKO_ROADMAP_XLSX', 'roadmap.xlsx')

class WriteLockedError(Exception):
    pass

def _safe_to_excel(writer, sheet_name: str, df: pd.DataFrame):
    """Write without NaN/NaT strings; keep blanks empty."""
    df2 = df.copy()
    for c in df2.columns:
        df2[c] = df2[c].apply(lambda v: None if (pd.isna(v) or str(v).lower() == 'nan') else v)
    df2.to_excel(writer, sheet_name=sheet_name, index=False)

def ensure_workbook():
    p = Path(EXCEL_PATH)
    if not p.exists():
        with pd.ExcelWriter(EXCEL_PATH, engine='openpyxl') as w:
            _safe_to_excel(w, 'goals', pd.DataFrame(columns=['id','name','year','due_date','description']))
            _safe_to_excel(w, 'challenges', pd.DataFrame(columns=['id','title','due_date','description']))
            _safe_to_excel(w, 'capabilities', pd.DataFrame(columns=['id','title','subarea_id','description']))
            _safe_to_excel(w, 'resources', pd.DataFrame(columns=['id','title','subarea_id','description']))
            _safe_to_excel(w, 'areas', pd.DataFrame(columns=['area_id','area_name','rank']))
            _safe_to_excel(w, 'subareas', pd.DataFrame(columns=['subarea_id','area_id','subarea_name','rank']))
            _safe_to_excel(w, 'goal_challenge', pd.DataFrame(columns=['goal_id','challenge_id']))
            _safe_to_excel(w, 'capability_challenge', pd.DataFrame(columns=['capability_id','challenge_id']))
            _safe_to_excel(w, 'capability_resource', pd.DataFrame(columns=['capability_id','resource_id']))
            _safe_to_excel(w, 'changelog', pd.DataFrame(columns=['date','version','note','author']))

def _read_sheet(name: str) -> pd.DataFrame:
    ensure_workbook()
    try:
        df = pd.read_excel(EXCEL_PATH, sheet_name=name, engine='openpyxl')
    except ValueError:
        with pd.ExcelWriter(EXCEL_PATH, engine='openpyxl', mode='a', if_sheet_exists='overlay') as w:
            _safe_to_excel(w, name, pd.DataFrame())
        df = pd.read_excel(EXCEL_PATH, sheet_name=name, engine='openpyxl')
    return df

def _write_sheet(name: str, df: pd.DataFrame):
    try:
        with pd.ExcelWriter(EXCEL_PATH, engine='openpyxl', mode='a', if_sheet_exists='replace') as w:
            _safe_to_excel(w, name, df)
    except PermissionError as e:
        raise WriteLockedError("roadmap.xlsx is locked by another application. Close it and try again.") from e

# ----- READERS -----

def read_changelog() -> pd.DataFrame:
    df = _read_sheet('changelog')
    # normalise expected columns
    for c in ['date','version','note','author']:
        if c not in df.columns: df[c] = None
    return df


def read_goals() -> pd.DataFrame:
    df = _read_sheet('goals')
    for c in ['id','name','year','due_date','description']:
        if c not in df.columns: df[c] = None
    return df

def read_challenges() -> pd.DataFrame:
    df = _read_sheet('challenges')
    for c in ['id','title','due_date','description']:
        if c not in df.columns: df[c] = None
    return df

def read_capabilities() -> pd.DataFrame:
    df = _read_sheet('capabilities')
    for c in ['id','title','subarea_id','description']:
        if c not in df.columns: df[c] = None
    return df

def read_resources() -> pd.DataFrame:
    df = _read_sheet('resources')
    for c in ['id','title','subarea_id','description']:
        if c not in df.columns: df[c] = None
    return df

def read_areas() -> pd.DataFrame:
    df = _read_sheet('areas')
    for c in ['area_id','area_name','rank']:
        if c not in df.columns: df[c] = None
    return df

def read_subareas() -> pd.DataFrame:
    df = _read_sheet('subareas')
    for c in ['subarea_id','area_id','subarea_name','rank']:
        if c not in df.columns: df[c] = None
    return df

def read_goal_challenge() -> pd.DataFrame:
    df = _read_sheet('goal_challenge')
    for c in ['goal_id','challenge_id']:
        if c not in df.columns: df[c] = None
    return df

def read_capability_challenge() -> pd.DataFrame:
    df = _read_sheet('capability_challenge')
    for c in ['capability_id','challenge_id']:
        if c not in df.columns: df[c] = None
    return df

def read_capability_resource() -> pd.DataFrame:
    df = _read_sheet('capability_resource')
    for c in ['capability_id','resource_id']:
        if c not in df.columns: df[c] = None
    return df

# ----- UPDATERS -----
def update_goal(goal_id: int, name: str, year: int, due_date: str, description: str):
    df = read_goals()
    idx = df.index[df['id'] == int(goal_id)]
    if len(idx) == 0: raise ValueError(f'Goal id {goal_id} not found')
    df.loc[idx, 'name'] = name
    df.loc[idx, 'year'] = int(year)
    if due_date:
        d = pd.to_datetime(due_date, errors='coerce')
        df.loc[idx, 'due_date'] = ('' if pd.isna(d) else d.date().isoformat())
    else:
        df.loc[idx, 'due_date'] = ''
    df.loc[idx, 'description'] = description
    _write_sheet('goals', df)

def update_challenge(challenge_id: int, title: str, due_date: str, description: str):
    df = read_challenges()
    idx = df.index[df['id'] == int(challenge_id)]
    if len(idx) == 0: raise ValueError(f'Challenge id {challenge_id} not found')
    df.loc[idx, 'title'] = title
    if due_date:
        d = pd.to_datetime(due_date, errors='coerce')
        df.loc[idx, 'due_date'] = ('' if pd.isna(d) else d.date().isoformat())
    else:
        df.loc[idx, 'due_date'] = ''
    df.loc[idx, 'description'] = description
    _write_sheet('challenges', df)

def update_capability(capability_id: int, title: str, subarea_id: int, description: str):
    df = read_capabilities()
    idx = df.index[df['id'] == int(capability_id)]
    if len(idx) == 0: raise ValueError(f'Capability id {capability_id} not found')
    df.loc[idx, 'title'] = title
    df.loc[idx, 'subarea_id'] = int(subarea_id)
    df.loc[idx, 'description'] = description
    _write_sheet('capabilities', df)

def update_resource(resource_id: int, subarea_id: int | None, title: str, description: str):
    df = read_resources()
    idx = df.index[df['id'] == int(resource_id)]
    if len(idx) == 0: raise ValueError(f'Resource id {resource_id} not found')
    df.loc[idx, 'title'] = title
    df.loc[idx, 'subarea_id'] = (None if subarea_id is None else int(subarea_id))
    df.loc[idx, 'description'] = description
    _write_sheet('resources', df)

def update_area(area_id: int, area_name: str, rank: int | None):
    df = read_areas()
    idx = df.index[df['area_id'] == int(area_id)]
    if len(idx) == 0: raise ValueError(f'Area id {area_id} not found')
    df.loc[idx, 'area_name'] = area_name
    df.loc[idx, 'rank'] = rank
    _write_sheet('areas', df)

def update_subarea(subarea_id: int, area_id: int, subarea_name: str, rank: int | None):
    df = read_subareas()
    idx = df.index[df['subarea_id'] == int(subarea_id)]
    if len(idx) == 0: raise ValueError(f'Sub-area id {subarea_id} not found')
    df.loc[idx, 'area_id'] = int(area_id)
    df.loc[idx, 'subarea_name'] = subarea_name
    df.loc[idx, 'rank'] = rank
    _write_sheet('subareas', df)

# ----- CREATORS -----
def add_area(name: str, rank: int | None):
    df = read_areas()
    next_id = (int(df['area_id'].max()) + 1) if not df.empty else 1
    df = pd.concat([df, pd.DataFrame([{'area_id': next_id, 'area_name': name, 'rank': rank}])], ignore_index=True)
    _write_sheet('areas', df)
    return next_id

def add_subarea(area_id: int, name: str, rank: int | None):
    df = read_subareas()
    next_id = (int(df['subarea_id'].max()) + 1) if not df.empty else 1
    df = pd.concat([df, pd.DataFrame([{'subarea_id': next_id, 'area_id': int(area_id), 'subarea_name': name, 'rank': rank}])], ignore_index=True)
    _write_sheet('subareas', df)
    return next_id

def add_goal(name: str, year: int, due_date: str | None, description: str):
    df = read_goals()
    next_id = (int(df['id'].max()) + 1) if not df.empty else 1
    rec = {'id': next_id, 'name': name, 'year': int(year)}
    if due_date:
        d = pd.to_datetime(due_date, errors='coerce')
        rec['due_date'] = ('' if pd.isna(d) else d.date().isoformat())
    else:
        rec['due_date'] = ''
    rec['description'] = description
    df = pd.concat([df, pd.DataFrame([rec])], ignore_index=True)
    _write_sheet('goals', df)
    return next_id

def add_challenge(title: str, due_date: str | None, description: str):
    df = read_challenges()
    next_id = (int(df['id'].max()) + 1) if not df.empty else 1
    rec = {'id': next_id, 'title': title}
    if due_date:
        d = pd.to_datetime(due_date, errors='coerce')
        rec['due_date'] = ('' if pd.isna(d) else d.date().isoformat())
    else:
        rec['due_date'] = ''
    rec['description'] = description
    df = pd.concat([df, pd.DataFrame([rec])], ignore_index=True)
    _write_sheet('challenges', df)
    return next_id

def add_capability(title: str, subarea_id: int, description: str):
    df = read_capabilities()
    next_id = (int(df['id'].max()) + 1) if not df.empty else 1
    rec = {'id': next_id, 'title': title, 'subarea_id': int(subarea_id), 'description': description}
    df = pd.concat([df, pd.DataFrame([rec])], ignore_index=True)
    _write_sheet('capabilities', df)
    return next_id

def add_resource(title: str, subarea_id: int, description: str):
    df = read_resources()
    next_id = (int(df['id'].max()) + 1) if not df.empty else 1
    rec = {'id': next_id, 'title': title, 'subarea_id': int(subarea_id), 'description': description}
    df = pd.concat([df, pd.DataFrame([rec])], ignore_index=True)
    _write_sheet('resources', df)
    return next_id



def delete_challenge(challenge_id: int):
    df = read_challenges()
    idx = df.index[df['id'] == int(challenge_id)]
    if len(idx) == 0:
        raise ValueError(f'Challenge id {challenge_id} not found')
    df = df.drop(index=idx)
    _write_sheet('challenges', df)
# ----- LINK TOGGLERS -----
def toggle_link_goal_challenge(goal_id: int, challenge_id: int, enabled: bool):
    df = read_goal_challenge()
    mask = (df['goal_id'] == int(goal_id)) & (df['challenge_id'] == int(challenge_id))
    exists = df[mask]
    changed = False
    if enabled and exists.empty:
        df = pd.concat([df, pd.DataFrame([{'goal_id': int(goal_id), 'challenge_id': int(challenge_id)}])], ignore_index=True)
        changed = True
    if (not enabled) and not exists.empty:
        df = df.drop(exists.index)
        changed = True
    if changed:
        _write_sheet('goal_challenge', df)

def toggle_link_capability_challenge(capability_id: int, challenge_id: int, enabled: bool):
    df = read_capability_challenge()
    mask = (df['capability_id'] == int(capability_id)) & (df['challenge_id'] == int(challenge_id))
    exists = df[mask]
    changed = False
    if enabled and exists.empty:
        df = pd.concat([df, pd.DataFrame([{'capability_id': int(capability_id), 'challenge_id': int(challenge_id)}])], ignore_index=True)
        changed = True
    if (not enabled) and not exists.empty:
        df = df.drop(exists.index)
        changed = True
    if changed:
        _write_sheet('capability_challenge', df)

def toggle_link_capability_resource(capability_id: int, resource_id: int, enabled: bool):
    df = read_capability_resource()
    mask = (df['capability_id'] == int(capability_id)) & (df['resource_id'] == int(resource_id))
    exists = df[mask]
    changed = False
    if enabled and exists.empty:
        df = pd.concat([df, pd.DataFrame([{'capability_id': int(capability_id), 'resource_id': int(resource_id)}])], ignore_index=True)
        changed = True
    if (not enabled) and not exists.empty:
        df = df.drop(exists.index)
        changed = True
    if changed:
        _write_sheet('capability_resource', df)
