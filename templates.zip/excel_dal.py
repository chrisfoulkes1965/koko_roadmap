from __future__ import annotations
import os
from pathlib import Path
import pandas as pd

EXCEL_PATH = os.environ.get('KOKO_ROADMAP_XLSX', 'roadmap.xlsx')

class WriteLockedError(Exception):
    pass

def _safe_to_excel(writer, sheet_name: str, df: pd.DataFrame):
    """Write without NaN/NaT strings; keep blanks empty."""
    df2 = df.copy()
    for c in df2.columns:
        df2[c] = df2[c].apply(lambda v: None if (pd.isna(v) or str(v).lower() == 'nan') else v)
    df2.to_excel(writer, sheet_name=sheet_name, index=False)

def ensure_workbook():
    p = Path(EXCEL_PATH)
    if not p.exists():
        with pd.ExcelWriter(EXCEL_PATH, engine='openpyxl') as w:
            _safe_to_excel(w, 'ambitions', pd.DataFrame(columns=['id','name','due_date','description','display']))
            _safe_to_excel(w, 'constraints', pd.DataFrame(columns=['id','title','due_date','description']))
            _safe_to_excel(w, 'enablers', pd.DataFrame(columns=['id','title','subarea_id','description']))
            _safe_to_excel(w, 'requirements', pd.DataFrame(columns=['id','title','subarea_id','description']))
            _safe_to_excel(w, 'areas', pd.DataFrame(columns=['area_id','area_name','rank']))
            _safe_to_excel(w, 'subareas', pd.DataFrame(columns=['subarea_id','area_id','subarea_name','rank']))
            _safe_to_excel(w, 'ambition_constraint', pd.DataFrame(columns=['ambition_id','constraint_id']))
            _safe_to_excel(w, 'constraint-enabler', pd.DataFrame(columns=['enabler_id','constraint_id']))
            _safe_to_excel(w, 'enabler-requirement', pd.DataFrame(columns=['enabler_id','resource_id']))
            _safe_to_excel(w, 'changelog', pd.DataFrame(columns=['date','version','note','author']))

def _read_sheet(name: str) -> pd.DataFrame:
    ensure_workbook()
    try:
        df = pd.read_excel(EXCEL_PATH, sheet_name=name, engine='openpyxl')
    except PermissionError as e:
        raise WriteLockedError("roadmap.xlsx is locked by another application. Close it and try again.") from e
    except ValueError:
        # Try case-insensitive match first
        try:
            import openpyxl
            wb = openpyxl.load_workbook(EXCEL_PATH, read_only=True)
            sheet_names = wb.sheetnames
            wb.close()
            # Find case-insensitive match
            matched_name = None
            for sheet_name in sheet_names:
                if sheet_name.lower() == name.lower():
                    matched_name = sheet_name
                    break
            if matched_name:
                df = pd.read_excel(EXCEL_PATH, sheet_name=matched_name, engine='openpyxl')
            else:
                # Create empty sheet if not found
                with pd.ExcelWriter(EXCEL_PATH, engine='openpyxl', mode='a', if_sheet_exists='overlay') as w:
                    _safe_to_excel(w, name, pd.DataFrame())
                df = pd.read_excel(EXCEL_PATH, sheet_name=name, engine='openpyxl')
        except Exception:
            # Fallback: create empty sheet
            with pd.ExcelWriter(EXCEL_PATH, engine='openpyxl', mode='a', if_sheet_exists='overlay') as w:
                _safe_to_excel(w, name, pd.DataFrame())
            df = pd.read_excel(EXCEL_PATH, sheet_name=name, engine='openpyxl')
    return df

def _write_sheet(name: str, df: pd.DataFrame):
    try:
        with pd.ExcelWriter(EXCEL_PATH, engine='openpyxl', mode='a', if_sheet_exists='replace') as w:
            _safe_to_excel(w, name, df)
    except PermissionError as e:
        raise WriteLockedError("roadmap.xlsx is locked by another application. Close it and try again.") from e

# ----- READERS -----

def read_changelog() -> pd.DataFrame:
    df = _read_sheet('changelog')
    # normalise expected columns
    for c in ['date','version','note','author']:
        if c not in df.columns: df[c] = None
    return df


def read_ambitions() -> pd.DataFrame:
    df = _read_sheet('ambitions')
    # Normalize column names to lowercase for case-insensitive matching
    df.columns = df.columns.astype(str).str.lower()
    for c in ['id','name','due_date','description','display']:
        if c not in df.columns: df[c] = None
    # Convert display column to numeric, preserving 0 values and NaN (which means default Yes)
    if 'display' in df.columns:
        # Convert to numeric, coercing errors to NaN
        df['display'] = pd.to_numeric(df['display'], errors='coerce')
        # Don't fill NaN - keep it as NaN (means default Yes, but not explicitly set)
        # Only convert non-NaN values to int
        mask = df['display'].notna()
        df.loc[mask, 'display'] = df.loc[mask, 'display'].astype(int)
    else:
        df['display'] = pd.NA  # Use pd.NA to indicate not set (defaults to Yes)
    return df

def read_constraints() -> pd.DataFrame:
    df = _read_sheet('constraints')
    for c in ['id','title','due_date','description']:
        if c not in df.columns: df[c] = None
    return df

def read_enablers() -> pd.DataFrame:
    df = _read_sheet('enablers')
    for c in ['id','title','subarea_id','description']:
        if c not in df.columns: df[c] = None
    return df

def read_resources() -> pd.DataFrame:
    df = _read_sheet('requirements')
    for c in ['id','title','subarea_id','description']:
        if c not in df.columns: df[c] = None
    return df

def read_areas() -> pd.DataFrame:
    df = _read_sheet('areas')
    for c in ['area_id','area_name','rank']:
        if c not in df.columns: df[c] = None
    return df

def read_subareas() -> pd.DataFrame:
    df = _read_sheet('subareas')
    for c in ['subarea_id','area_id','subarea_name','rank']:
        if c not in df.columns: df[c] = None
    return df

def read_ambition_constraint() -> pd.DataFrame:
    df = _read_sheet('ambition_constraint')
    # Map new column names (ambition_id, constraint_id) to internal names (goal_id, constraint_id) for compatibility
    # Note: goal_id/constraint_id are kept as internal identifiers, mapped from ambition_id/constraint_id
    if 'ambition_id' in df.columns and 'goal_id' not in df.columns:
        df['goal_id'] = df['ambition_id']
    if 'constraint_id' in df.columns and 'constraint_id' not in df.columns:
        df['constraint_id'] = df['constraint_id']
    for c in ['goal_id','constraint_id']:
        if c not in df.columns: df[c] = None
    return df

def read_enabler_constraint() -> pd.DataFrame:
    df = _read_sheet('constraint-enabler')
    # Handle new column names (constraint_id, enabler_id) and map to old names (constraint_id, enabler_id)
    if 'constraint_id' in df.columns and 'constraint_id' not in df.columns:
        df['constraint_id'] = df['constraint_id']
    if 'enabler_id' in df.columns and 'enabler_id' not in df.columns:
        df['enabler_id'] = df['enabler_id']
    for c in ['enabler_id','constraint_id']:
        if c not in df.columns: df[c] = None
    return df

def read_enabler_resource() -> pd.DataFrame:
    df = _read_sheet('enabler-requirement')
    # Handle new column names (enabler_id, requirement_id) and map to old names (enabler_id, resource_id)
    if 'enabler_id' in df.columns and 'enabler_id' not in df.columns:
        df['enabler_id'] = df['enabler_id']
    if 'requirement_id' in df.columns and 'resource_id' not in df.columns:
        df['resource_id'] = df['requirement_id']
    for c in ['enabler_id','resource_id']:
        if c not in df.columns: df[c] = None
    return df

# ----- UPDATERS -----
def update_ambition(ambition_id: int, name: str, due_date: str, description: str, display: int | None = None):
    df = read_ambitions()
    idx = df.index[df['id'] == int(ambition_id)]
    if len(idx) == 0: raise ValueError(f'Ambition id {ambition_id} not found')
    df.loc[idx, 'name'] = name
    if due_date:
        d = pd.to_datetime(due_date, errors='coerce')
        df.loc[idx, 'due_date'] = ('' if pd.isna(d) else d.date().isoformat())
    else:
        df.loc[idx, 'due_date'] = ''
    df.loc[idx, 'description'] = description
    if display is not None:
        df.loc[idx, 'display'] = int(display)
    _write_sheet('ambitions', df)

def update_constraint(constraint_id: int, title: str, due_date: str, description: str):
    df = read_constraints()
    idx = df.index[df['id'] == int(constraint_id)]
    if len(idx) == 0: raise ValueError(f'Constraint id {constraint_id} not found')
    df.loc[idx, 'title'] = title
    if due_date:
        d = pd.to_datetime(due_date, errors='coerce')
        df.loc[idx, 'due_date'] = ('' if pd.isna(d) else d.date().isoformat())
    else:
        df.loc[idx, 'due_date'] = ''
    df.loc[idx, 'description'] = description
    _write_sheet('constraints', df)

def update_enabler(enabler_id: int, title: str, subarea_id: int, description: str):
    df = read_enablers()
    idx = df.index[df['id'] == int(enabler_id)]
    if len(idx) == 0: raise ValueError(f'enabler id {enabler_id} not found')
    df.loc[idx, 'title'] = title
    df.loc[idx, 'subarea_id'] = int(subarea_id)
    df.loc[idx, 'description'] = description
    _write_sheet('enablers', df)

def update_resource(resource_id: int, subarea_id: int | None, title: str, description: str):
    df = read_resources()
    idx = df.index[df['id'] == int(resource_id)]
    if len(idx) == 0: raise ValueError(f'Resource id {resource_id} not found')
    df.loc[idx, 'title'] = title
    df.loc[idx, 'subarea_id'] = (None if subarea_id is None else int(subarea_id))
    df.loc[idx, 'description'] = description
    _write_sheet('requirements', df)

def update_area(area_id: int, area_name: str, rank: int | None):
    df = read_areas()
    idx = df.index[df['area_id'] == int(area_id)]
    if len(idx) == 0: raise ValueError(f'Area id {area_id} not found')
    df.loc[idx, 'area_name'] = area_name
    df.loc[idx, 'rank'] = rank
    _write_sheet('areas', df)

def update_subarea(subarea_id: int, area_id: int, subarea_name: str, rank: int | None):
    df = read_subareas()
    idx = df.index[df['subarea_id'] == int(subarea_id)]
    if len(idx) == 0: raise ValueError(f'Sub-area id {subarea_id} not found')
    df.loc[idx, 'area_id'] = int(area_id)
    df.loc[idx, 'subarea_name'] = subarea_name
    df.loc[idx, 'rank'] = rank
    _write_sheet('subareas', df)

# ----- CREATORS -----
def add_area(name: str, rank: int | None):
    df = read_areas()
    next_id = (int(df['area_id'].max()) + 1) if not df.empty else 1
    df = pd.concat([df, pd.DataFrame([{'area_id': next_id, 'area_name': name, 'rank': rank}])], ignore_index=True)
    _write_sheet('areas', df)
    return next_id

def add_subarea(area_id: int, name: str, rank: int | None):
    df = read_subareas()
    next_id = (int(df['subarea_id'].max()) + 1) if not df.empty else 1
    df = pd.concat([df, pd.DataFrame([{'subarea_id': next_id, 'area_id': int(area_id), 'subarea_name': name, 'rank': rank}])], ignore_index=True)
    _write_sheet('subareas', df)
    return next_id

def add_ambition(name: str, due_date: str | None, description: str, display: int | None = None):
    df = read_ambitions()
    next_id = (int(df['id'].max()) + 1) if not df.empty else 1
    rec = {'id': next_id, 'name': name}
    if due_date:
        d = pd.to_datetime(due_date, errors='coerce')
        rec['due_date'] = ('' if pd.isna(d) else d.date().isoformat())
    else:
        rec['due_date'] = ''
    rec['description'] = description
    rec['display'] = int(display) if display is not None else 1  # Default to visible
    df = pd.concat([df, pd.DataFrame([rec])], ignore_index=True)
    _write_sheet('ambitions', df)
    return next_id

def add_constraint(title: str, due_date: str | None, description: str):
    df = read_constraints()
    next_id = (int(df['id'].max()) + 1) if not df.empty else 1
    rec = {'id': next_id, 'title': title}
    if due_date:
        d = pd.to_datetime(due_date, errors='coerce')
        rec['due_date'] = ('' if pd.isna(d) else d.date().isoformat())
    else:
        rec['due_date'] = ''
    rec['description'] = description
    df = pd.concat([df, pd.DataFrame([rec])], ignore_index=True)
    _write_sheet('constraints', df)
    return next_id

def add_enabler(title: str, subarea_id: int, description: str):
    df = read_enablers()
    next_id = (int(df['id'].max()) + 1) if not df.empty else 1
    rec = {'id': next_id, 'title': title, 'subarea_id': int(subarea_id), 'description': description}
    df = pd.concat([df, pd.DataFrame([rec])], ignore_index=True)
    _write_sheet('enablers', df)
    return next_id

def add_resource(title: str, subarea_id: int, description: str):
    df = read_resources()
    next_id = (int(df['id'].max()) + 1) if not df.empty else 1
    rec = {'id': next_id, 'title': title, 'subarea_id': int(subarea_id), 'description': description}
    df = pd.concat([df, pd.DataFrame([rec])], ignore_index=True)
    _write_sheet('requirements', df)
    return next_id



def delete_constraint(constraint_id: int):
    df = read_constraints()
    idx = df.index[df['id'] == int(constraint_id)]
    if len(idx) == 0:
        raise ValueError(f'Constraint id {constraint_id} not found')
    df = df.drop(index=idx)
    _write_sheet('constraints', df)


def delete_enabler(enabler_id: int):
    df = read_enablers()
    idx = df.index[df['id'] == int(enabler_id)]
    if len(idx) == 0:
        raise ValueError(f'enabler id {enabler_id} not found')
    df = df.drop(index=idx)
    _write_sheet('enablers', df)


def delete_resource(resource_id: int):
    df = read_resources()
    idxs = df.index[df['id'] == int(resource_id)]
    if len(idxs) == 0:
        raise ValueError(f"Resource id {resource_id} not found")
    df = df.drop(index=idxs)
    _write_sheet('requirements', df)


def delete_ambition(ambition_id: int):
    df = read_ambitions()
    idx = df.index[df['id'] == int(ambition_id)]
    if len(idx) == 0:
        raise ValueError(f'Ambition id {ambition_id} not found')
    df = df.drop(index=idx)
    _write_sheet('ambitions', df)
# ----- LINK TOGGLERS -----
def toggle_link_ambition_constraint(ambition_id: int, constraint_id: int, enabled: bool):
    df = read_ambition_constraint()
    mask = (df['goal_id'] == int(ambition_id)) & (df['constraint_id'] == int(constraint_id))
    exists = df[mask]
    changed = False
    if enabled and exists.empty:
        df = pd.concat([df, pd.DataFrame([{'goal_id': int(ambition_id), 'constraint_id': int(constraint_id)}])], ignore_index=True)
        changed = True
    if (not enabled) and not exists.empty:
        df = df.drop(exists.index)
        changed = True
    if changed:
        _write_sheet('ambition_constraint', df)

def toggle_link_enabler_constraint(enabler_id: int, constraint_id: int, enabled: bool):
    df = read_enabler_constraint()
    mask = (df['enabler_id'] == int(enabler_id)) & (df['constraint_id'] == int(constraint_id))
    exists = df[mask]
    changed = False
    if enabled and exists.empty:
        df = pd.concat([df, pd.DataFrame([{'enabler_id': int(enabler_id), 'constraint_id': int(constraint_id)}])], ignore_index=True)
        changed = True
    if (not enabled) and not exists.empty:
        df = df.drop(exists.index)
        changed = True
    if changed:
        _write_sheet('constraint-enabler', df)

def toggle_link_enabler_resource(enabler_id: int, resource_id: int, enabled: bool):
    df = read_enabler_resource()
    mask = (df['enabler_id'] == int(enabler_id)) & (df['resource_id'] == int(resource_id))
    exists = df[mask]
    changed = False
    if enabled and exists.empty:
        df = pd.concat([df, pd.DataFrame([{'enabler_id': int(enabler_id), 'resource_id': int(resource_id)}])], ignore_index=True)
        changed = True
    if (not enabled) and not exists.empty:
        df = df.drop(exists.index)
        changed = True
    if changed:
        _write_sheet('enabler-requirement', df)
