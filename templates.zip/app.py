from __future__ import annotations
import os
from pathlib import Path
from flask import Flask, render_template, request, jsonify, redirect, url_for, render_template_string
import pandas as pd

from excel_dal import (
    EXCEL_PATH, ensure_workbook,
    read_ambitions, read_constraints, read_enablers, read_resources,
    read_areas, read_subareas,
    read_ambition_constraint, read_enabler_constraint, read_enabler_resource,
    update_ambition, update_constraint, update_enabler, update_resource,
    update_area, update_subarea,
    add_area, add_subarea, add_ambition, add_constraint, add_enabler, add_resource,
    toggle_link_ambition_constraint, toggle_link_enabler_constraint, toggle_link_enabler_resource,
    delete_ambition,
    delete_resource,
    delete_enabler,
    delete_constraint,
    WriteLockedError
)

from changelog_dal import read_changelog

app = Flask(__name__)


@app.errorhandler(WriteLockedError)
def handle_write_locked_error(e):
    """Handle file lock errors with a user-friendly message."""
    return render_template_string("""
    {% extends 'base.html' %}
    {% block content %}
    <div style="padding: 2rem; max-width: 600px; margin: 0 auto;">
        <h2>File Locked</h2>
        <p style="color: #d32f2f; font-size: 1.1em; margin: 1rem 0;">
            {{ error_message }}
        </p>
        <p>Please:</p>
        <ul>
            <li>Close Microsoft Excel if you have <code>roadmap.xlsx</code> open</li>
            <li>Close any other programs that might be using the file</li>
            <li>Wait a few seconds and refresh this page</li>
        </ul>
        <div style="margin-top: 2rem;">
            <a href="{{ url_for('home') }}" class="btn primary">Go to Home</a>
            <button onclick="window.location.reload()" class="btn">Retry</button>
        </div>
    </div>
    {% endblock %}
    """, error_message=str(e)), 423


@app.get('/__routes')
def __routes():
    return '<pre>' + '\n'.join(sorted(str(r) for r in app.url_map.iter_rules())) + '</pre>'


@app.before_request
def _ensure_xlsx():
    ensure_workbook()

def _fmt_date_only(x):
    if x in (None, '', pd.NaT):
        return ''
    try:
        d = pd.to_datetime(x, errors='coerce')
        if pd.isna(d): return ''
        return d.date().isoformat()
    except Exception:
        return ''

@app.context_processor
def inject_excel_path():
    return dict(excel_path=str(Path(EXCEL_PATH).resolve()))


@app.get('/')
def home():
    # If you’re using changelog_dal.py, prefer: from changelog_dal import read_changelog
    # and call that instead of reading directly.
    csv_path = Path(os.environ.get("KOKO_ROADMAP_CHANGELOG", "changelog.csv"))
    if not csv_path.exists():
        rows = []
    else:
        df = pd.read_csv(csv_path)
        # normalise column names
        cols = {c.lower(): c for c in df.columns}
        # pick a sortable date col
        if 'timestamp' in cols:
            sortcol = cols['timestamp']
        elif 'date' in cols:
            sortcol = cols['date']
        else:
            sortcol = None
        if sortcol:
            df['_sort'] = pd.to_datetime(df[sortcol], errors='coerce')
            df = df.sort_values('_sort', ascending=False).drop(columns=['_sort'])
        rows = df.to_dict(orient='records')

    return render_template('index.html', changelog=rows)



@app.get('/ambitions')
def ambitions():
    gs = read_ambitions().copy()
    # Show ALL ambitions by default - no filtering
    # Filter out rows where id is NaN or None
    if not gs.empty:
        gs = gs[gs['id'].notna()]
    ch = read_constraints()
    gc = read_ambition_constraint()
    titles_by_id = ch.set_index('id')['title'].to_dict() if not ch.empty else {}
    constraint_titles = {gid: [titles_by_id.get(cid,'') for cid in gc[gc['goal_id']==gid]['constraint_id'].tolist()] for gid in gs['id'].tolist()} if not gs.empty else {}
    rows = []
    for _, r in gs.iterrows():
        try:
            ambition_id = r.get('id')
            if pd.isna(ambition_id) or ambition_id is None:
                continue
            display_val = r.get('display')
            # Convert to Yes/No: 1 or NaN = Yes, 0 = No
            display_text = 'No' if (pd.notna(display_val) and int(display_val) == 0) else 'Yes'
            rows.append(dict(
                id=int(ambition_id),
                name=r.get('name',''),
                due_date=r.get('due_date',''),
                due_date_disp=_fmt_date_only(r.get('due_date','')),
                description='' if (pd.isna(r.get('description')) or str(r.get('description')).lower()=='nan') else r.get('description',''),
                display=display_text,
                display_value=int(display_val) if pd.notna(display_val) else 1,  # For form submission
                constraint_titles=sorted([t for t in constraint_titles.get(int(ambition_id),[]) if t])
            ))
        except Exception as e:
            # Skip rows with errors, but log them
            import sys
            print(f"Error processing ambition row: {e}", file=sys.stderr)
            continue
    return render_template('goals.html', goals=rows)

@app.get('/constraints')
def constraints():
    ch = read_constraints().copy()
    gs = read_ambitions()
    gc = read_ambition_constraint()
    cc = read_enabler_constraint()
    caps = read_enablers()

    ambition_due = {}
    if not gs.empty and not gc.empty:
        g_due = gs.set_index('id')['due_date'].to_dict()
        for cid in ch['id'].tolist():
            g_ids = gc[gc['constraint_id']==cid]['goal_id'].tolist()
            ds = pd.to_datetime([g_due.get(g) for g in g_ids], errors='coerce')
            ambition_due[cid] = ds.min() if len(ds)>0 and not pd.isna(ds).all() else None

    cap_titles = caps.set_index('id')['title'].to_dict() if not caps.empty else {}
    cc_map = {cid: [cap_titles.get(k,'') for k in cc[cc['constraint_id']==cid]['enabler_id'].tolist()] for cid in ch['id'].tolist()} if not ch.empty else {}

    rows = []
    for _, r in ch.iterrows():
        rows.append(dict(
            id=int(r['id']), title=r.get('title',''),
            due_date=r.get('due_date',''), due_date_disp=_fmt_date_only(r.get('due_date','')),
            earliest_ambition_due_disp=_fmt_date_only(ambition_due.get(int(r['id']))),
            description='' if (pd.isna(r.get('description')) or str(r.get('description')).lower()=='nan') else r.get('description',''),
            ambition_titles=sorted([t for t in gc[gc['constraint_id']==int(r['id'])]['goal_id'].map(gs.set_index('id')['name']).fillna('').tolist() if t!='']),
            cap_titles=sorted([t for t in cc_map.get(int(r['id']),[]) if t!=''])
        ))
    return render_template('challenges.html', constraints=rows)

@app.get('/enablers')
def enablers():
    caps = read_enablers().copy()
    cr = read_enabler_resource()
    res = read_resources()
    cc = read_enabler_constraint()
    ch = read_constraints()
    areas = read_areas()
    subs = read_subareas()

    caps = caps.merge(subs[['subarea_id','subarea_name','area_id']], how='left', on='subarea_id')
    caps = caps.merge(areas[['area_id','area_name','rank']].rename(columns={'rank':'area_rank'}), how='left', on='area_id')
    caps = caps.merge(subs[['subarea_id','rank']].rename(columns={'rank':'sub_rank'}), how='left', on='subarea_id')

    # compute earliest due date of linked constraints
    earliest_due = {}
    ch_due = ch.set_index('id')['due_date'].to_dict() if not ch.empty else {}
    for cap_id in caps['id'].tolist():
        cids = cc[cc['enabler_id']==cap_id]['constraint_id'].tolist()
        ds = pd.to_datetime([ch_due.get(k) for k in cids], errors='coerce')
        earliest_due[cap_id] = ds.min() if len(ds) > 0 and not pd.isna(ds).all() else None

    res_titles = res.set_index('id')['title'].to_dict() if not res.empty else {}
    res_map = {cap_id: [res_titles.get(rid,'') for rid in cr[cr['enabler_id']==cap_id]['resource_id'].tolist()] for cap_id in caps['id'].tolist()} if not caps.empty else {}

    # constraints linked to enabler
    ch_titles = ch.set_index('id')['title'].to_dict() if not ch.empty else {}
    constraint_map = {cap_id: [ch_titles.get(cid,'') for cid in cc[cc['enabler_id']==cap_id]['constraint_id'].tolist()] for cap_id in caps['id'].tolist()} if not caps.empty else {}

    rows = []
    for _, r in caps.iterrows():
        due_val = earliest_due.get(int(r['id']))
        due_iso = _fmt_date_only(due_val)  # ISO yyyy-mm-dd for both display and modal
        rows.append(dict(
            id=int(r['id']), title=r.get('title',''),
            subarea_id=int(r['subarea_id']) if pd.notna(r.get('subarea_id')) else None,
            area_id=int(r.get('area_id')) if pd.notna(r.get('area_id')) else None,
            area_name=r.get('area_name',''), subarea_name=r.get('subarea_name',''),
            description='' if (pd.isna(r.get('description')) or str(r.get('description')).lower()=='nan') else r.get('description',''),
            resource_titles=sorted([t for t in res_map.get(int(r['id']),[]) if t!='']),
            constraint_titles=sorted([t for t in constraint_map.get(int(r['id']),[]) if t!='']),
            earliest_due_disp=due_iso,      # table column
            earliest_due_iso=due_iso        # modal input
        ))
    return render_template('capabilities.html',
                           enablers=rows,
                           areas=read_areas().to_dict(orient='records'),
                           subareas=read_subareas().to_dict(orient='records'))

@app.get('/resources')
def resources():
    res = read_resources().copy()
    caps = read_enablers()
    subs = read_subareas()
    areas = read_areas()
    cr = read_enabler_resource()

    res = res.merge(subs[['subarea_id','subarea_name','area_id']], how='left', on='subarea_id')
    res = res.merge(areas[['area_id','area_name']], how='left', on='area_id')

    cap_titles = caps.set_index('id')['title'].to_dict() if not caps.empty else {}
    cap_map = {rid: [cap_titles.get(k,'') for k in cr[cr['resource_id']==rid]['enabler_id'].tolist()] for rid in res['id'].tolist()} if not res.empty else {}

    rows = []
    for _, r in res.iterrows():
        rows.append(dict(
            id=int(r['id']), title=r.get('title',''),
            subarea_id=int(r['subarea_id']) if pd.notna(r.get('subarea_id')) else None,
            area_id=int(r.get('area_id')) if pd.notna(r.get('area_id')) else None,
            area_name=r.get('area_name',''), subarea_name=r.get('subarea_name',''),
            description='' if (pd.isna(r.get('description')) or str(r.get('description')).lower()=='nan') else r.get('description',''),
            cap_titles=sorted([t for t in cap_map.get(int(r['id']),[]) if t!=''])
        ))
    return render_template('resources.html', resources=rows, areas=read_areas().to_dict(orient='records'), subareas=read_subareas().to_dict(orient='records'))

@app.get('/areas')
def areas():
    ar = read_areas()
    sb = read_subareas()
    ar_sorted = ar.sort_values(['rank','area_name'], na_position='last', kind='stable')
    subs_by = {}
    for _, r in ar_sorted.iterrows():
        subs = sb[sb['area_id']==r['area_id']].sort_values(['rank','subarea_name'], na_position='last', kind='stable')
        subs_by[int(r['area_id'])] = [dict(subarea_id=int(x['subarea_id']), subarea_name=x.get('subarea_name',''), rank=(None if pd.isna(x.get('rank')) else int(x['rank']))) for _, x in subs.iterrows()]
    areas_rows = [dict(area_id=int(r['area_id']), area_name=r.get('area_name',''), rank=(None if pd.isna(r.get('rank')) else int(r['rank']))) for _, r in ar_sorted.iterrows()]
    return render_template('areas.html', areas=areas_rows, subareas_by_area=subs_by)


@app.get('/sankey')
def sankey():
    # Data
    gs   = read_ambitions()
    # Filter out ambitions where display is explicitly 0 (No), but keep NaN/null (default to Yes)
    gs = gs[(gs['display'].isna()) | (gs['display'] != 0)]
    ch   = read_constraints()
    caps = read_enablers()
    res  = read_resources()
    subs = read_subareas()
    areas= read_areas()
    gc   = read_ambition_constraint()
    cc   = read_enabler_constraint()
    cr   = read_enabler_resource()

    # Merge ranks onto enablers/resources
    subs_rank  = subs[['subarea_id','area_id','rank']].rename(columns={'rank':'sub_rank'})
    areas_rank = areas[['area_id','rank']].rename(columns={'rank':'area_rank'})
    caps2 = caps.merge(subs_rank, how='left', on='subarea_id').merge(areas_rank, how='left', on='area_id')
    res2  = res.merge(subs_rank,  how='left', on='subarea_id').merge(areas_rank,  how='left', on='area_id')

    # Helpers
    def _iso(x):  # ISO date ('' if blank/invalid)
        return _fmt_date_only(x)

    # Options payloads for the template (always defined -> no blank modals)
    ambitions_rows = [] if gs.empty else [
        dict(id=int(r['id']), name=r.get('name',''), due=_iso(r.get('due_date','')))
        for _, r in gs.iterrows()
    ]
    constraint_rows  = [] if ch.empty else [
        dict(id=int(r['id']), title=r.get('title',''), due=_iso(r.get('due_date','')))
        for _, r in ch.iterrows()
    ]
    cap_rows = [] if caps2.empty else [
        dict(
            id=int(r['id']), title=r.get('title',''),
            area_id=(None if pd.isna(r.get('area_id')) else int(r['area_id'])),
            subarea_id=(None if pd.isna(r.get('subarea_id')) else int(r['subarea_id'])),
            area_rank=(None if pd.isna(r.get('area_rank')) else int(r['area_rank'])),
            sub_rank=(None if pd.isna(r.get('sub_rank')) else int(r['sub_rank']))
        )
        for _, r in caps2.iterrows()
    ]
    res_rows = [] if res2.empty else [
        dict(
            id=int(r['id']), title=r.get('title',''),
            area_id=(None if pd.isna(r.get('area_id')) else int(r['area_id'])),
            subarea_id=(None if pd.isna(r.get('subarea_id')) else int(r['subarea_id'])),
            area_rank=(None if pd.isna(r.get('area_rank')) else int(r['area_rank'])),
            sub_rank=(None if pd.isna(r.get('sub_rank')) else int(r['sub_rank']))
        )
        for _, r in res2.iterrows()
    ]
    area_rows = [] if areas.empty else [
        dict(area_id=int(r['area_id']), area_name=r.get('area_name',''),
             rank=(None if pd.isna(r.get('rank')) else int(r['rank'])))
        for _, r in areas.iterrows()
    ]
    sub_rows = [] if subs.empty else [
        dict(subarea_id=int(r['subarea_id']),
             area_id=(None if pd.isna(r.get('area_id')) else int(r['area_id'])),
             subarea_name=r.get('subarea_name',''),
             rank=(None if pd.isna(r.get('rank')) else int(r['rank'])))
        for _, r in subs.iterrows()
    ]

    # Edges for 4-column flow: Ambitions→Constraints→Enablers→Requirements
    gc_edges = [] if gc.empty else [
        dict(g=int(r['goal_id']), c=int(r['constraint_id']))
        for _, r in gc.iterrows()
        if pd.notna(r.get('goal_id')) and pd.notna(r.get('constraint_id'))
    ]
    cc_edges = [] if cc.empty else [
        dict(c=int(r['constraint_id']), p=int(r['enabler_id']))
        for _, r in cc.iterrows()
        if pd.notna(r.get('constraint_id')) and pd.notna(r.get('enabler_id'))
    ]
    cr_edges = [] if cr.empty else [
        dict(p=int(r['enabler_id']), r=int(r['resource_id']))
        for _, r in cr.iterrows()
        if pd.notna(r.get('enabler_id')) and pd.notna(r.get('resource_id'))
    ]

    payload = dict(
        goals=ambitions_rows,
        constraints=constraint_rows,
        enablers=cap_rows,
        resources=res_rows,
        areas=area_rows,
        subareas=sub_rows,
        edges=dict(gc=gc_edges, cc=cc_edges, cr=cr_edges)
    )
    height = int(request.args.get('h', '900'))
    return render_template('sankey.html', data=payload, height=height)



# ----- Linking UIs -----
@app.get('/links/ambition/<int:ambition_id>')
def links_ambition(ambition_id: int):
    gs = read_ambitions(); ch = read_constraints(); gc = read_ambition_constraint()
    g = gs[gs['id']==ambition_id]
    if g.empty: return redirect(url_for('ambitions'))
    linked = set(gc[gc['goal_id']==ambition_id]['constraint_id'].tolist())
    rows = ch.sort_values(['title']).to_dict(orient='records')
    return render_template_string("""
    {% extends 'base.html' %}{% block content %}
    <h2>Link Ambition to Constraints: {{ g.name }}</h2>
    <form method="post">
      {% for r in rows %}
        <div><label><input type="checkbox" name="cid" value="{{ r.id }}" {% if r.id in linked %}checked{% endif %}> {{ r.title }}</label></div>
      {% endfor %}
      <div class="actions" style="margin-top:.75rem"><button class="btn primary">Save</button></div>
    </form>
    {% endblock %}
    """, g=dict(id=int(g.iloc[0]['id']), name=g.iloc[0]['name']), rows=rows, linked=linked)

@app.post('/links/ambition/<int:ambition_id>')
def links_ambition_post(ambition_id: int):
    ch = read_constraints()
    submitted = set([int(x) for x in request.form.getlist('cid')])
    all_ids = set(ch['id'].tolist()) if not ch.empty else set()
    for cid in all_ids:
        toggle_link_ambition_constraint(ambition_id, cid, cid in submitted)
    return redirect(url_for('ambitions'))


@app.get('/links/constraint/<int:cid>/enablers')
def links_constraint_caps(cid: int):
    caps = read_enablers(); cc = read_enabler_constraint()
    ch = read_constraints()
    c = ch[ch['id']==cid]
    if c.empty: return redirect(url_for('constraints'))
    linked = set(cc[cc['constraint_id']==cid]['enabler_id'].tolist())
    rows = caps.sort_values(['title']).to_dict(orient='records')
    if request.args.get('embed') == '1':
        return render_template_string("""        <h3>Link Enablers to Constraint: {{ c.title }}</h3>
        <form id="constraint-caps-form" method="post" action="{{ url_for('links_constraint_caps_post', cid=c.id) }}">
          {% for r in rows %}
            <div><label><input type="checkbox" name="pid" value="{{ r.id }}" {% if r.id in linked %}checked{% endif %}> {{ r.title }}</label></div>
          {% endfor %}
          <div class="actions" style="margin-top:.75rem">
            <button type="button" class="btn" id="cc_cancel">Cancel</button>
            <button class="btn primary">Save</button>
          </div>
        </form>
        """, c=dict(id=int(c.iloc[0]['id']), title=c.iloc[0]['title']), rows=rows, linked=linked)
    return render_template_string("""    {% extends 'base.html' %}{% block content %}
    <h2>Link Enablers to Constraint: {{ c.title }}</h2>
    <form method="post">
      {% for r in rows %}
        <div><label><input type="checkbox" name="pid" value="{{ r.id }}" {% if r.id in linked %}checked{% endif %}> {{ r.title }}</label></div>
      {% endfor %}
      <div class="actions" style="margin-top:.75rem"><button class="btn primary">Save</button></div>
    </form>
    {% endblock %}
    """, c=dict(id=int(c.iloc[0]['id']), title=c.iloc[0]['title']), rows=rows, linked=linked)

@app.post('/links/constraint/<int:cid>/enablers')
def links_constraint_caps_post(cid: int):
    caps = read_enablers()
    submitted = set([int(x) for x in request.form.getlist('pid')])
    all_ids = set(caps['id'].tolist()) if not caps.empty else set()
    for pid in all_ids:
        toggle_link_enabler_constraint(pid, cid, pid in submitted)
    return redirect(url_for('constraints'))


@app.get('/links/constraint/<int:cid>/ambitions')
def links_constraint_ambitions(cid: int):
    gs = read_ambitions(); gc = read_ambition_constraint(); ch = read_constraints()
    c = ch[ch['id']==cid]
    if c.empty: return redirect(url_for('constraints'))
    linked = set(gc[gc['constraint_id']==cid]['goal_id'].tolist())
    rows = gs.sort_values(['name']).to_dict(orient='records')
    if request.args.get('embed') == '1':
        return render_template_string("""        <h3>Link Ambitions to Constraint: {{ c.title }}</h3>
        <form id="constraint-ambitions-form" method="post" action="{{ url_for('links_constraint_ambitions_post', cid=c.id) }}">
          {% for r in rows %}
            <div><label><input type="checkbox" name="gid" value="{{ r.id }}" {% if r.id in linked %}checked{% endif %}> {{ r.name }}</label></div>
          {% endfor %}
          <div class="actions" style="margin-top:.75rem">
            <button type="button" class="btn" id="cg_cancel">Cancel</button>
            <button class="btn primary">Save</button>
          </div>
        </form>
        """, c=dict(id=int(c.iloc[0]['id']), title=c.iloc[0]['title']), rows=rows, linked=linked)
    return render_template_string("""    {% extends 'base.html' %}{% block content %}
    <h2>Link Ambitions to Constraint: {{ c.title }}</h2>
    <form method="post">
      {% for r in rows %}
        <div><label><input type="checkbox" name="gid" value="{{ r.id }}" {% if r.id in linked %}checked{% endif %}> {{ r.name }}</label></div>
      {% endfor %}
      <div class="actions" style="margin-top:.75rem"><button class="btn primary">Save</button></div>
    </form>
    {% endblock %}
    """, c=dict(id=int(c.iloc[0]['id']), title=c.iloc[0]['title']), rows=rows, linked=linked)

@app.post('/links/constraint/<int:cid>/ambitions')
def links_constraint_ambitions_post(cid: int):
    gs = read_ambitions()
    submitted = set(int(x) for x in request.form.getlist('gid'))
    all_ids = set(gs['id'].tolist()) if not gs.empty else set()
    for gid in all_ids:
        toggle_link_ambition_constraint(gid, cid, gid in submitted)
    return redirect(url_for('constraints'))


@app.get('/links/enabler/<int:pid>/resources')
def links_cap_res(pid: int):
    res = read_resources(); cr = read_enabler_resource()
    caps = read_enablers()
    p = caps[caps['id']==pid]
    if p.empty: return redirect(url_for('enablers'))
    linked = set(cr[cr['enabler_id']==pid]['resource_id'].tolist())
    rows = res.sort_values(['title']).to_dict(orient='records')
    return render_template_string("""            <h3>Link Constraints to Requirement: {{ p.title }}</h3>
    <form method="post">
      {% for r in rows %}
        <div>
          <label>
            <input type="checkbox" name="rid" value="{{ r.id }}" {% if r.id in linked %}checked{% endif %}>
            {{ r.title }}
          </label>
        </div>
      {% endfor %}
      <div class="actions" style="margin-top:.75rem">
        <button class="btn primary">Save</button>
      </div>
    </form>
    
    """, p=dict(id=int(p.iloc[0]['id']), title=p.iloc[0]['title']), rows=rows, linked=linked)




@app.get('/links/enabler/<int:pid>/constraints')
def links_cap_constraint(pid: int):
    caps = read_enablers(); cc = read_enabler_constraint()
    ch = read_constraints()
    p = caps[caps['id']==pid]
    if p.empty: return redirect(url_for('enablers'))
    linked = set(cc[cc['enabler_id']==pid]['constraint_id'].tolist())
    rows = ch.sort_values(['title']).to_dict(orient='records')
    if request.args.get('embed') == '1':
        return render_template_string("""            <h3>Link Constraints to Enabler: {{ p.title }}</h3>
        <form id="cap-constraint-form" method="post" action="{{ url_for('links_cap_constraint_post', pid=p.id) }}">
          {% for r in rows %}
            <div><label><input type="checkbox" name="cid" value="{{ r.id }}" {% if r.id in linked %}checked{% endif %}> {{ r.title }}</label></div>
          {% endfor %}
          <div class="actions" style="margin-top:.75rem">
            <button type="button" class="btn" id="cc_cancel">Cancel</button>
            <button class="btn primary">Save</button>
          </div>
        </form>
        """, p=dict(id=int(p.iloc[0]['id']), title=p.iloc[0]['title']), rows=rows, linked=linked)
    return render_template_string("""        {% extends 'base.html' %}{% block content %}
    <h2>Link Constraints to Enabler: {{ p.title }}</h2>
    <form method="post">
      {% for r in rows %}
        <div><label><input type="checkbox" name="cid" value="{{ r.id }}" {% if r.id in linked %}checked{% endif %}> {{ r.title }}</label></div>
      {% endfor %}
      <div class="actions" style="margin-top:.75rem"><button class="btn primary">Save</button></div>
    </form>
    {% endblock %}
    """, p=dict(id=int(p.iloc[0]['id']), title=p.iloc[0]['title']), rows=rows, linked=linked)

@app.post('/links/enabler/<int:pid>/constraints')
def links_cap_constraint_post(pid: int):
    ch = read_constraints()
    submitted = set([int(x) for x in request.form.getlist('cid')])
    all_ids = set(ch['id'].tolist()) if not ch.empty else set()
    for cid in all_ids:
        toggle_link_enabler_constraint(pid, cid, cid in submitted)
    return redirect(url_for('enablers'))


@app.get('/links/resource/<int:rid>/enablers')
def links_res_caps(rid: int):
    res = read_resources(); caps = read_enablers(); cr = read_enabler_resource()
    r = res[res['id']==rid]
    if r.empty: return redirect(url_for('resources'))
    linked = set(cr[cr['resource_id']==rid]['enabler_id'].tolist())
    rows = caps.sort_values(['title']).to_dict(orient='records')
    if request.args.get('embed') == '1':
        return render_template_string("""            <h3>Link Enablers to Requirement: {{ r.title }}</h3>
        <form id="res-caps-form" method="post" action="{{ url_for('links_res_caps_post', rid=r.id) }}">
          {% for p in rows %}
            <div><label><input type="checkbox" name="pid" value="{{ p.id }}" {% if p.id in linked %}checked{% endif %}> {{ p.title }}</label></div>
          {% endfor %}
          <div class="actions" style="margin-top:.75rem">
            <button type="button" class="btn" id="rc_cancel">Cancel</button>
            <button class="btn primary">Save</button>
          </div>
        </form>
        """, r=dict(id=int(r.iloc[0]['id']), title=r.iloc[0]['title']), rows=rows, linked=linked)
    return render_template_string("""        {% extends 'base.html' %}{% block content %}
    <h2>Link Enablers to Requirement: {{ r.title }}</h2>
    <form method="post">
      {% for p in rows %}
        <div><label><input type="checkbox" name="pid" value="{{ p.id }}" {% if p.id in linked %}checked{% endif %}> {{ p.title }}</label></div>
      {% endfor %}
      <div class="actions" style="margin-top:.75rem"><button class="btn primary">Save</button></div>
    </form>
    {% endblock %}
    """, r=dict(id=int(r.iloc[0]['id']), title=r.iloc[0]['title']), rows=rows, linked=linked)

@app.post('/links/resource/<int:rid>/enablers')
def links_res_caps_post(rid: int):
    caps = read_enablers()
    submitted = set([int(x) for x in request.form.getlist('pid')])
    all_ids = set(caps['id'].tolist()) if not caps.empty else set()
    for pid in all_ids:
        toggle_link_enabler_resource(pid, rid, pid in submitted)
    return redirect(url_for('resources'))
@app.post('/links/enabler/<int:pid>/resources')
def links_cap_res_post(pid: int):
    res = read_resources()
    submitted = set([int(x) for x in request.form.getlist('rid')])
    all_ids = set(res['id'].tolist()) if not res.empty else set()
    for rid in all_ids:
        toggle_link_enabler_resource(pid, rid, rid in submitted)
    return redirect(url_for('enablers'))

# ----- Inline EDIT endpoints -----
def _get(field: str, default: str = '') -> str:
    if request.is_json:
        data = request.get_json(silent=True) or {}
        return (data.get(field, default) or '').strip()
    return (request.form.get(field, default) or '').strip()

@app.route('/ambitions/<int:ambition_id>/edit-inline', methods=['POST'])
def ambitions_edit_inline(ambition_id: int):
    name = _get('name'); due = _get('due_date'); desc = _get('description'); display_raw = _get('display')
    if not name: return jsonify(ok=False, error='Name is required.'), 400
    display = None
    if display_raw and display_raw.lstrip('-').isdigit():
        display = int(display_raw)
    try:
        update_ambition(ambition_id, name, due, desc, display)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True), 200



@app.post('/ambitions/<int:ambition_id>/delete-inline')
def ambitions_delete_inline(ambition_id: int):
    gc = read_ambition_constraint()
    if not gc.empty and (gc['goal_id'] == int(ambition_id)).any():
        return jsonify(ok=False, error='Cannot delete: ambition is linked to one or more constraints.'), 400
    try:
        delete_ambition(ambition_id)
    except WriteLockedError as e:
        return jsonify(ok=False, error=str(e)), 423
    except Exception as e:
        return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True), 200
@app.route('/constraints/<int:constraint_id>/edit-inline', methods=['POST'])
def constraints_edit_inline(constraint_id: int):
    title = _get('title'); due = _get('due_date'); desc = _get('description')
    if not title: return jsonify(ok=False, error='Title is required.'), 400
    try:
        update_constraint(constraint_id, title, due, desc)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True), 200



@app.post('/constraints/<int:constraint_id>/delete-inline')
def constraints_delete_inline(constraint_id: int):
    # Cannot delete if linked to any ambitions or enablers
    gc = read_ambition_constraint()
    cc = read_enabler_constraint()
    if (not gc.empty and (gc['constraint_id'] == int(constraint_id)).any()) or (not cc.empty and (cc['constraint_id'] == int(constraint_id)).any()):
        return jsonify(ok=False, error='Cannot delete: constraint is linked to ambitions or enablers.'), 400
    try:
        delete_constraint(constraint_id)
    except WriteLockedError as e:
        return jsonify(ok=False, error=str(e)), 423
    except Exception as e:
        return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True), 200
@app.route('/enablers/<int:enabler_id>/edit-inline', methods=['POST'])
def enablers_edit_inline(enabler_id: int):
    title = _get('title'); subarea_id = _get('subarea_id'); desc = _get('description')
    if not title: return jsonify(ok=False, error='Title is required.'), 400
    if not subarea_id.isdigit(): return jsonify(ok=False, error='Sub-area is required.'), 400
    try:
        update_enabler(enabler_id, title, int(subarea_id), desc)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True), 200



@app.post('/enablers/<int:enabler_id>/delete-inline')
def enablers_delete_inline(enabler_id: int):
    # Cannot delete if linked to any constraints or resources
    cc = read_enabler_constraint()
    cr = read_enabler_resource()
    if (not cc.empty and (cc['enabler_id'] == int(enabler_id)).any()) or (not cr.empty and (cr['enabler_id'] == int(enabler_id)).any()):
        return jsonify(ok=False, error='Cannot delete: enabler is linked to constraints or requirements.'), 400
    try:
        delete_enabler(enabler_id)
    except WriteLockedError as e:
        return jsonify(ok=False, error=str(e)), 423
    except Exception as e:
        return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True), 200
@app.route('/resources/<int:resource_id>/edit-inline', methods=['POST'])
def resources_edit_inline(resource_id: int):
    title = _get('title'); subarea_id = _get('subarea_id'); desc = _get('description')
    if not title: return jsonify(ok=False, error='Title is required.'), 400
    try:
        sub_id = int(subarea_id) if subarea_id.isdigit() else None
        update_resource(resource_id, sub_id, title, desc)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True), 200



@app.post('/resources/<int:resource_id>/delete-inline')
def resources_delete_inline(resource_id: int):
    cr = read_enabler_resource()
    if not cr.empty and (cr['resource_id'] == int(resource_id)).any():
        return jsonify(ok=False, error='Cannot delete: requirement is linked to enablers.'), 400
    try:
        delete_resource(resource_id)
    except WriteLockedError as e:
        return jsonify(ok=False, error=str(e)), 423
    except Exception as e:
        return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True), 200
@app.route('/areas/<int:area_id>/edit-inline', methods=['POST'])
def areas_edit_inline(area_id: int):
    name = _get('area_name'); rank_raw = _get('rank')
    rank = int(rank_raw) if rank_raw and rank_raw.lstrip('-').isdigit() else None
    if not name: return jsonify(ok=False, error='Area name is required.'), 400
    try:
        update_area(area_id, name, rank)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True), 200

@app.route('/areas/sub/<int:subarea_id>/edit-inline', methods=['POST'])
def subareas_edit_inline(subarea_id: int):
    name = _get('subarea_name'); area_id_raw = _get('area_id'); rank_raw = _get('rank')
    if not name: return jsonify(ok=False, error='Sub-area name is required.'), 400
    if not area_id_raw.isdigit(): return jsonify(ok=False, error='Area is required.'), 400
    rank = int(rank_raw) if rank_raw and rank_raw.lstrip('-').isdigit() else None
    try:
        update_subarea(subarea_id, int(area_id_raw), name, rank)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True), 200

# ----- Inline ADD endpoints -----
@app.post('/ambitions/add-inline')
def ambitions_add_inline():
    name = _get('name'); due = _get('due_date'); desc = _get('description'); display_raw = _get('display')
    if not name: return jsonify(ok=False, error='Name is required.'), 400
    display = None
    if display_raw and display_raw.lstrip('-').isdigit():
        display = int(display_raw)
    try:
        new_id = add_ambition(name, due, desc, display)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True, id=new_id), 200

@app.post('/constraints/add-inline')
def constraints_add_inline():
    title = _get('title'); due = _get('due_date'); desc = _get('description')
    if not title: return jsonify(ok=False, error='Title is required.'), 400
    try:
        new_id = add_constraint(title, due, desc)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True, id=new_id), 200

@app.post('/enablers/add-inline')
def enablers_add_inline():
    title = _get('title'); subarea_id = _get('subarea_id'); desc = _get('description')
    if not title: return jsonify(ok=False, error='Title is required.'), 400
    if not subarea_id.isdigit(): return jsonify(ok=False, error='Sub-area is required.'), 400
    try:
        new_id = add_enabler(title, int(subarea_id), desc)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True, id=new_id), 200

@app.post('/resources/add-inline')
def resources_add_inline():
    title = _get('title'); subarea_id = _get('subarea_id'); desc = _get('description')
    if not title: return jsonify(ok=False, error='Title is required.'), 400
    if not subarea_id.isdigit(): return jsonify(ok=False, error='Sub-area is required.'), 400
    try:
        new_id = add_resource(title, int(subarea_id), desc)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True, id=new_id), 200

@app.post('/areas/add-inline')
def areas_add_inline():
    name = _get('area_name'); rank_raw = _get('rank')
    if not name: return jsonify(ok=False, error='Area name is required.'), 400
    rank = int(rank_raw) if rank_raw and rank_raw.lstrip('-').isdigit() else None
    try:
        new_id = add_area(name, rank)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True, id=new_id), 200

# NEW: add missing sub-area CREATE endpoint to match the UI
@app.post('/areas/sub/add-inline')
def subareas_add_inline():
    name = _get('subarea_name'); area_id_raw = _get('area_id'); rank_raw = _get('rank')
    if not name: return jsonify(ok=False, error='Sub-area name is required.'), 400
    if not area_id_raw.isdigit(): return jsonify(ok=False, error='Area is required.'), 400
    rank = int(rank_raw) if rank_raw and rank_raw.lstrip('-').isdigit() else None
    try:
        new_id = add_subarea(int(area_id_raw), name, rank)
    except WriteLockedError as e: return jsonify(ok=False, error=str(e)), 423
    except Exception as e: return jsonify(ok=False, error=f'Unexpected: {e}'), 500
    return jsonify(ok=True, id=new_id), 200

if __name__ == '__main__':
    app.run(debug=True)
